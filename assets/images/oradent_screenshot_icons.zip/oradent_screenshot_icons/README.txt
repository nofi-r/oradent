Oradent onboarding icons based on your screenshots
PNG, 512x512, transparent background.
Brand colors: navy #0F3E75 and ice blue #B3D2D8.

Files:
01_welcome_shield_plus.png - Welcome to Oradent (shield + medical cross)
02_dental_treatment_first_aid_kit.png - Explore Dental Treatments (medical kit + cross)
03_appointment_calendar.png - Book Your Appointment (calendar)
04_optional_tooth_sparkle.png - optional dental-themed icon

Put these files in your Flutter project's assets/images/ folder.
These are icon image assets; replace the built-in Icon(...) widgets with Image.asset(...).
Your screenshot icons sit on an ice-blue rounded square background, which can remain in Flutter Container decoration.
